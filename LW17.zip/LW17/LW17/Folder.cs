﻿using System.Collections.ObjectModel;
using System.IO;
using System.Windows;

namespace LW17
{
    public class Folder
    {
        public string Path { get; set; }

        public string Name { get; set; }

        public ObservableCollection<Folder> SubFolders { get; set; }

        public ObservableCollection<FileItem> Files { get; set; }

        public Folder(string path)
        {
            Path = path;
            Name = System.IO.Path.GetDirectoryName(path);
            SubFolders = GetSubFolders(path);
            Files = GetFiles(path);
            MessageBox.Show($"{Path}");
        }

        private ObservableCollection<FileItem>? GetFiles(string path)
        {
            var files = new ObservableCollection<FileItem>();
            var subFiles = Directory.GetFiles(path);
            foreach (var fileFullName in subFiles)
            {
                var file = new FileItem(fileFullName);
                files.Add(file);
            }
            return files;
        }

        private ObservableCollection<Folder> GetSubFolders(string path)
        {
            try
            {
                var subfolders = new ObservableCollection<Folder>();
                var subFoldersPaths = Directory.GetDirectories(path,"*", searchOption:SearchOption.AllDirectories);
                foreach (var subFolder in subFoldersPaths)
                {
                    var folder = new Folder(subFolder);
                    subfolders.Add(folder);
                }
                return subfolders;
            }
            catch
            {
                return null;
            }           
        }
    }
}
