﻿using System.Collections.ObjectModel;
using System.IO;
using System.Windows;

namespace LW17
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Folder Folder { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            LoadFolder();
        }

        private void LoadFolder()
        {
            Folder = new Folder(SearchTextBox.Text);
            FoldersTreeView.Items.Add(Folder);
            MessageBox.Show(Folder.SubFolders[0].SubFolders[0].Name);
        }

        private void GenerateFolderTree(Folder folder)
        {
            foreach (var sub in folder.SubFolders)
            {

            }
        }

        private void SearchFolderButton_Click(object sender, RoutedEventArgs e)
        {
            LoadFolder();
        }
    }
}