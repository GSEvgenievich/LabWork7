﻿using System.IO;

namespace LW17
{
    public class FileItem
    {

        public string IconPath { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public DateTime Modified { get; set; }

        public FileItem(string fullName)
        {
            Name = Path.GetFileName(fullName);
            Type = Path.GetExtension(fullName);
            IconPath = GetFileIcon(Type);
            Modified = File.GetLastAccessTime(fullName);
        }

        private string GetFileIcon(string fileExtension)
        {
            switch (fileExtension.ToLower())
            {
                case ".txt":
                    return "pack://application:,,,/Icons/text.png";
                case ".jpg":
                case ".jpeg":
                case ".png":
                    return "pack://application:,,,/Icons/image.png";
                case ".pdf":
                case ".webp":
                case ".xml":
                    return "pack://application:,,,/Icons/web.png";
                case ".folder":
                    return "pack://application:,,,/Icons/folder.png";
                default:
                    return "pack://application:,,,/Icons/default.png";
            }
        }
    }
}
